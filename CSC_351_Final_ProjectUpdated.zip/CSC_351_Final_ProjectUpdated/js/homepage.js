function openForm() {
	window.location.href = "html/login.html";
	};