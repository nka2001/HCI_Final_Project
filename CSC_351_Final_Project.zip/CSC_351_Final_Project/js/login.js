

function closeForm() {
	window.location.href = "../index.html";
};