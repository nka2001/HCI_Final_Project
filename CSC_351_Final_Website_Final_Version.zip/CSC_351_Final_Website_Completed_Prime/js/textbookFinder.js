
const notSelected = {
    name: "",
    price: "",
    inStock: "",
    Course: ""
}
const data_structures_and_algorithms = {
    name: "Introduction to Algorithms",
    price: "$169.00",
    inStock: "Yes",
    Course: "CSC 329 - Data Structures and Algs II"
}
const software_engineering = {
    name: "Software Engineering 10th edition",
    price: "$149.99",
    inStock: "No",
    Course: "CSC 325 - Software Engineering"
}
const operating_systems = {
    name: "Operating Systems: Three Easy Pieces",
    price: "$129.99",
    inStock: "Yes",
    Course: "CSC 343 - Operating Systems",
}


var optionData = {
    notSelected,
    data_structures_and_algorithms,
    software_engineering,
    operating_systems

};

var BookName = document.getElementById("Bname")
var BookPrice = document.getElementById("Bprice")
var BookInventory = document.getElementById("Binventory")
var BookCourse = document.getElementById("Bcourse")
var BookNotFound = document.getElementById("notFound")

var myDropdown = document.getElementById("myDropdown");

var showFormRadio = document.getElementById("prod1");
var myForm = document.getElementById("searchForm");
var showDropdownRadio = document.getElementById("showDropdown");
var myDropdown = document.getElementById("myDropdown");

myDropdown.addEventListener("change", function () {
    BookNotFound.style.display = "none";
    var selectedOption = myDropdown.value;

    BookName.innerText = optionData[selectedOption].name;
    BookPrice.innerText = optionData[selectedOption].price;
    BookInventory.innerText = optionData[selectedOption].inStock;
    BookCourse.innerText = optionData[selectedOption].Course;


});


function updateLabels() {
    // Get the book ID from the input field
    var bookId = document.getElementById("bookId").value;
    bookId = bookId.replace(/ /g, "_").toLowerCase();



    // Check if the book ID exists in the option data object
    if (optionData.hasOwnProperty(bookId)) {
        // Update the labels with the corresponding option data
        BookName.innerText = optionData[bookId].name;
        BookPrice.innerText = optionData[bookId].price;
        BookInventory.innerText = optionData[bookId].inStock;
        BookCourse.innerText = optionData[bookId].Course;
        BookNotFound.style.display = "none";


    } else {
        // If the book ID is not found in the option data object, display an error message
        BookNotFound.style.display = "block";
        BookName.innerText = "";
        BookInventory.innerText = "";
        BookPrice.innerText = "";
        BookCourse.innerText = "";
    }
    event.preventDefault();
}







var radioButtons = [showFormRadio, showDropdownRadio]


for (var i = 0; i < radioButtons.length; i++) {
    radioButtons[i].addEventListener("click", function () {
        setBook(i);


    })
}
function setBook(index) {
    console.log(index)
    if (showFormRadio.checked) {
        myForm.style.display = "block";
    } else {
        myForm.style.display = "none";
    }




    if (showDropdownRadio.checked) {
        myDropdown.style.display = "block";
    } else {
        myDropdown.style.display = "none";
    }


};





